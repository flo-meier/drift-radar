Drift Radar – Reproducible data bundle
======================================

Contents
--------
- raw/ – raw JSON responses from Peec AI MCP tools
    all_brands_report.json     get_brand_report across all brands
    pferdegold_brand_report.json  per-prompt × model report for Pferdegold
    sources_by_prompt.json     get_domain_report dimension=[prompt_id]
    chat_samples.json          get_chat payloads used as Deep-Dive samples
    claims.json                Haiku-extracted claims
    lookup_tables.json         ID ↔ name maps (brands, topics, models)
- ui/drift_radar.json – final pipeline output shown in the dashboard

Reproduction
------------
1. Peec MCP calls: 03-arbeit/drift-radar/run.py (OAuth-authenticated MCP)
2. Claim extraction: 03-arbeit/drift-radar/extract_claims.py (Claude Haiku 4.5)
3. Artifacts: 03-arbeit/drift-radar/export_downloads.py (this file)

License
-------
Source data © Peec AI (accessed via authorised OAuth). Derived artifacts © Drift Radar, released for the Peec AI MCP Challenge 2026 under the challenge IP terms (Peec receives worldwide, royalty-free license).
